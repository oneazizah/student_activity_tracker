import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Dummy test to make Flutter happy', () {
    expect(1 + 1, 2);
  });
}
